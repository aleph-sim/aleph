set -eu
cd /tmp/aleph-548-f6a7808
test ! -f measurement-started
tar -xzf aleph-548-followup.tar.gz -C source
cd source
python3 - <<'PY'
import json,pathlib,hashlib
x=json.load(open('../aleph-548-source-sha256.json'))
assert all(hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()==h for f,h in x.items())
print('final source manifest verified')
PY
CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR=../target nice -n 10 /root/.cargo/bin/cargo test --release -p aleph-stab > ../final-full-tests.log 2>&1
CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR=../target nice -n 10 /root/.cargo/bin/cargo build --release -p aleph-stab --example sparse_expectation --message-format=json > ../example-artifacts.jsonl 2> ../final-example-build.log
CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR=../target nice -n 10 /root/.cargo/bin/cargo bench -p aleph-stab --bench sparse_expectation --no-run --message-format=json > ../bench-artifacts.jsonl 2> ../final-bench-build.log
cd ..
touch measurement-started
python3 aleph-548-run.py
python3 aleph-548-summary.py .
