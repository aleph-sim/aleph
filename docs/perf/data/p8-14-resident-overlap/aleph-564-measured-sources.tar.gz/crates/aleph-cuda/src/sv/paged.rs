//! Out-of-core (host-memory paged) single-GPU state vector (P5.10-02).
//!
//! [`crate::sv::state::MAX_CUDA_QUBITS`] = 30 is the largest state that fits the
//! 20 GiB card (16 GiB of FP64 at n=30). Beyond that the `2^n` state must live in
//! host memory and stream through the device a tile at a time. This module holds
//! the full state in **pinned** host memory and processes each gate over
//! device-sized tiles, so n=31+ runs on one GPU at a bandwidth-bound cost.
//!
//! ## Tiling scheme
//!
//! Split the `n` qubits into the `m = tile_qubits` **low** bits (a device tile is
//! `2^m` contiguous amplitudes) and `h = n - m` **high** bits (which tile). The
//! global index is `x = (high << m) | low`; tile `T ∈ [0, 2^h)` is the host slice
//! `state[T·2^m .. (T+1)·2^m)`.
//!
//! A dense gate's result at each amplitude depends only on the *values* of the
//! amplitudes it pairs, never on the absolute index (only diagonal/phase kernels
//! read the index — those are deliberately excluded; the caller passes an
//! unfused gate circuit). So we apply **every** gate densely on a device-local
//! sub-state by *remapping* its qubits into device-local positions:
//!
//! - a gate touching high-qubit set `H` (`hh = |H|`) needs its `2^hh` tiles
//!   (varying the `H` bits, all other high bits fixed) **co-resident** on the
//!   device. We gather them into one contiguous device buffer at offsets
//!   `s·2^m` (`s ∈ [0, 2^hh)`), so device-local bit `m + rank` ↔ global qubit
//!   `H[rank]`; low qubits map to themselves.
//! - the gate is then a normal `(m + hh)`-qubit gate on that buffer — applied by
//!   reusing the existing in-core [`Backend::apply_gate`] kernels with the
//!   qubits/controls remapped — after which the tiles scatter back to host.
//!
//! Iterating over the `2^(h - hh)` "outer" high combinations covers the whole
//! state in exactly one read + one write per gate (bandwidth-optimal, same as
//! in-core). [`CudaSvBackend::run_paged`] issues those copies synchronously on
//! one stream; [`CudaSvBackend::run_paged_overlapped`] (P5.11-02) instead
//! double-buffers them across dedicated H2D/D2H/compute streams so the copy
//! directions overlap (~1.10× on the idle box, near the card's ~1.24× PCIe
//! duplex ceiling) — see `docs/perf/p5.11-02-overlapped-paging.md`.

use std::rc::Rc;

use aleph_backend::{Backend, BackendError};
use aleph_core::{Complex, GateInstance};
use aleph_ir::{Circuit, Instruction};
use cudarc::driver::{result, sys, CudaEvent, DevicePtr, PinnedHostSlice};

use crate::sv::backend::to_backend_err;
use crate::sv::state::{CudaSvState, MAX_CUDA_QUBITS};
use crate::sv::CudaSvBackend;
use crate::{CudaContext, Error};

/// An out-of-core state vector: the full `2 · 2^n` interleaved `[re, im]` FP64
/// amplitudes in pinned host memory. Produced by [`CudaSvBackend::run_paged`].
pub struct PagedSvState {
    num_qubits: u32,
    /// Interleaved `[re0, im0, re1, im1, …]`, length `2 · 2^n`, page-locked.
    host: PinnedHostSlice<f64>,
}

impl core::fmt::Debug for PagedSvState {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("PagedSvState")
            .field("num_qubits", &self.num_qubits)
            .field("amps", &(1u64 << self.num_qubits))
            .finish_non_exhaustive()
    }
}

impl PagedSvState {
    /// Number of qubits this state represents.
    pub fn num_qubits(&self) -> u32 {
        self.num_qubits
    }

    /// The amplitudes as `Vec<Complex>` (one per basis state). Allocates a second
    /// `2^n`-sized host buffer, so use only at the small `n` of oracle tests —
    /// never at n=31 (that would be another 32 GiB). For large `n` use
    /// [`Self::norm_sqr`], which streams the pinned buffer in place.
    pub fn amplitudes_vec(&self) -> Vec<Complex> {
        let host = self.host.as_slice().expect("pinned host sync");
        host.as_chunks::<2>()
            .0
            .iter()
            .map(|&[re, im]| Complex::new(re, im))
            .collect()
    }

    /// `Σ |amp|²`, streamed over the pinned buffer with no extra allocation. A
    /// cheap large-`n` sanity check (should be ≈ 1 for a unitary circuit).
    pub fn norm_sqr(&self) -> f64 {
        let host = self.host.as_slice().expect("pinned host sync");
        host.as_chunks::<2>()
            .0
            .iter()
            .map(|&[re, im]| re * re + im * im)
            .sum()
    }
}

/// High-bit index `T` whose bits at the `hprime` positions carry `s` (LSB-first)
/// and whose remaining positions carry `outer` (LSB-first). Reconstructs which
/// tile sub-block `s` of co-resident group `outer` maps to.
pub(crate) fn compose_high(outer: u64, s: u64, hprime: &[u32], h: u32) -> u64 {
    let mut val = 0u64;
    let mut oc = 0u32; // cursor over `outer`'s bits
    for p in 0..h {
        if let Some(rank) = hprime.iter().position(|&x| x == p) {
            if (s >> rank) & 1 == 1 {
                val |= 1u64 << p;
            }
        } else {
            if (outer >> oc) & 1 == 1 {
                val |= 1u64 << p;
            }
            oc += 1;
        }
    }
    val
}

impl CudaSvBackend {
    /// Run `circuit` **out-of-core**: hold the `2^n` state in pinned host memory
    /// and stream device-sized `2^tile_qubits` tiles through the GPU, one gate at
    /// a time (P5.10-02). This lifts the [`MAX_CUDA_QUBITS`] ceiling — n=31 fits a
    /// 20 GiB card — at a bandwidth-bound cost (each gate reads+writes the whole
    /// host state once).
    ///
    /// `tile_qubits` is the low-bit split `m`: a tile is `2^m` amplitudes
    /// (`2^m · 16 B`). It must satisfy `1 ≤ m < n`, and `m + g ≤ MAX_CUDA_QUBITS`
    /// where `g` is the most high-qubits any single gate touches (so the
    /// co-resident tile group fits the device). Forcing a small `m` at small `n`
    /// is how the oracle test exercises the paging path.
    ///
    /// Only [`Instruction::Gate`] and [`Instruction::Barrier`] are supported:
    /// the dense-apply tiling is exact for any unitary gate, but diagonal-phase
    /// and tiled-block instructions read the global index — pass an **unfused**
    /// circuit (no `DiagonalPhase`/`TiledBlock`), and handle measurement on the
    /// returned host state.
    pub fn run_paged(
        &mut self,
        circuit: &Circuit,
        tile_qubits: u32,
    ) -> Result<PagedSvState, BackendError> {
        let n = circuit.num_qubits();
        if n == 0 && circuit.is_empty() {
            return Err(BackendError::EmptyCircuit);
        }
        let m = tile_qubits;
        if m == 0 || m >= n {
            return Err(BackendError::InvalidState {
                reason: "paged tile_qubits must satisfy 1 <= tile_qubits < num_qubits",
            });
        }

        // Scan once: reject unsupported instructions and find the largest
        // high-qubit fan-out `g` (sizes the co-resident device group buffer).
        let mut g_max = 0u32;
        for inst in circuit.instructions() {
            match inst {
                Instruction::Gate(gate) => g_max = g_max.max(high_count(gate, m)),
                Instruction::Barrier(_) => {}
                Instruction::Measure { .. } => {
                    return Err(BackendError::UnsupportedInstruction { kind: "measure" })
                }
                Instruction::Reset(_) => {
                    return Err(BackendError::UnsupportedInstruction { kind: "reset" })
                }
                Instruction::DiagonalPhase(_) => {
                    return Err(BackendError::UnsupportedInstruction {
                        kind: "diagonal-phase",
                    })
                }
                Instruction::TiledBlock(_) => {
                    return Err(BackendError::UnsupportedInstruction {
                        kind: "tiled-block",
                    })
                }
            }
        }
        let local_qubits = m + g_max;
        if local_qubits > MAX_CUDA_QUBITS {
            return Err(BackendError::TooManyQubits {
                requested: local_qubits,
                limit: MAX_CUDA_QUBITS,
            });
        }

        let ctx = self.ctx();

        // Pinned host state: 2·2^n f64, zeroed, amplitude 0 set to |0…0⟩.
        let host_len = 2usize << n; // 2 · 2^n
                                    // SAFETY: `alloc_pinned` returns an owned page-locked allocation of
                                    // `host_len` f64; we initialise every element below before any copy
                                    // reads it. The slice is freed on `PagedSvState` drop.
        let mut host: PinnedHostSlice<f64> = unsafe { ctx.raw().alloc_pinned(host_len) }
            .map_err(|e| to_backend_err(Error::Driver(e)))?;
        {
            let s = host
                .as_mut_slice()
                .map_err(|e| to_backend_err(Error::Driver(e)))?;
            s.fill(0.0);
            s[0] = 1.0;
        }

        // One reusable device buffer big enough for the largest co-resident group
        // (2^(m + g_max) amplitudes); per gate we use only its 2^(m+hh) prefix.
        let mut group = CudaSvState::allocate(&ctx, local_qubits).map_err(to_backend_err)?;

        // Raw host base pointer (synchronises the pinned event once). All tile
        // copies sub-slice this; the regions a single gate touches are disjoint
        // and every copy is stream-ordered, so no CPU-side aliasing occurs.
        let base: *mut f64 = host
            .as_mut_ptr()
            .map_err(|e| to_backend_err(Error::Driver(e)))?;

        for inst in circuit.instructions() {
            if let Instruction::Gate(gate) = inst {
                self.apply_gate_paged(&ctx, &mut group, base, n, m, gate)?;
            }
        }
        ctx.synchronize().map_err(to_backend_err)?;
        Ok(PagedSvState {
            num_qubits: n,
            host,
        })
    }

    /// Run `circuit` out-of-core like [`Self::run_paged`], but with the tile
    /// copies **double-buffered and overlapped** (P5.11-02). The synchronous path
    /// issues gather → compute → scatter for each tile group on one stream, so
    /// they never overlap; here they run on three streams (H2D / compute / D2H)
    /// against two ping-pong device tile-group buffers, so `gather(i+1)`,
    /// `compute(i)`, and `scatter(i−1)` execute concurrently and the PCIe link
    /// stays busy in both directions (it is full-duplex).
    ///
    /// Correctness comes from explicit CUDA events:
    /// - `compute(i)` waits the gather of group `i`,
    /// - `scatter(i)` waits the compute of group `i`,
    /// - `gather(i)` reusing a ring buffer waits that buffer's previous scatter
    ///   (buffer-reuse hazard), and
    /// - the first gather of each **gate** waits the previous gate's last scatter
    ///   (the host-memory hazard: a gate reads tiles the prior gate wrote — the
    ///   D2H stream is in-order, so its last event covers all earlier scatters).
    ///
    /// `depth` is the number of ring buffers (pipeline depth, `≥ 2`). Two buffers
    /// is too shallow: the `gather(i) ← scatter(i−2)` dependency forces gather and
    /// scatter to *alternate* instead of overlap (it regresses below the
    /// synchronous path). A deeper ring (≈3–4) lets the H2D engine run ahead of
    /// D2H so both copy engines stay busy. The ring costs `depth · 2^(m+g)`
    /// device amplitudes, which must fit the card.
    ///
    /// Same state as [`Self::run_paged`] (oracle-pinned at 1e-10). The streams are
    /// `NonBlocking`, so they do not serialise against the legacy default stream.
    pub fn run_paged_overlapped(
        &mut self,
        circuit: &Circuit,
        tile_qubits: u32,
        depth: u32,
    ) -> Result<PagedSvState, BackendError> {
        self.run_paged_pipeline(circuit, tile_qubits, depth, false)
    }

    /// Combine low-qubit residency with event-ordered copy overlap (FP64, opt-in).
    /// Maximal low-only runs share one load/scatter per tile; high gates flush the
    /// run. Segments with fewer than `2*depth` groups use synchronous residency.
    /// The ring holds `depth * 2^(tile_qubits + max_high_fanout) * 16` bytes,
    /// in addition to the pinned `2^n * 16` byte host state and per-slot matrix
    /// scratch. Available host/device memory is preflighted with headroom. No FP32 mirror yet.
    ///
    /// ```no_run
    /// # fn main() -> Result<(), Box<dyn std::error::Error>> {
    /// let mut backend = aleph_cuda::CudaSvBackend::new()?;
    /// let mut circuit = aleph_ir::Circuit::new(10, 0);
    /// circuit.h(0)?;
    /// let state = backend.run_paged_batched_overlapped(&circuit, 6, 4)?;
    /// # Ok(())
    /// # }
    /// ```
    pub fn run_paged_batched_overlapped(
        &mut self,
        circuit: &Circuit,
        tile_qubits: u32,
        depth: u32,
    ) -> Result<PagedSvState, BackendError> {
        self.run_paged_pipeline(circuit, tile_qubits, depth, true)
    }

    fn run_paged_pipeline(
        &mut self,
        circuit: &Circuit,
        tile_qubits: u32,
        depth: u32,
        residency: bool,
    ) -> Result<PagedSvState, BackendError> {
        let n = circuit.num_qubits();
        if n == 0 && circuit.is_empty() {
            return Err(BackendError::EmptyCircuit);
        }
        let m = tile_qubits;
        if m == 0 || m >= n {
            return Err(BackendError::InvalidState {
                reason: "paged tile_qubits must satisfy 1 <= tile_qubits < num_qubits",
            });
        }
        let depth = depth.max(2) as usize;

        let mut g_max = 0u32;
        for inst in circuit.instructions() {
            match inst {
                Instruction::Gate(gate) => g_max = g_max.max(high_count(gate, m)),
                Instruction::Barrier(_) => {}
                Instruction::Measure { .. } => {
                    return Err(BackendError::UnsupportedInstruction { kind: "measure" })
                }
                Instruction::Reset(_) => {
                    return Err(BackendError::UnsupportedInstruction { kind: "reset" })
                }
                Instruction::DiagonalPhase(_) => {
                    return Err(BackendError::UnsupportedInstruction {
                        kind: "diagonal-phase",
                    })
                }
                Instruction::TiledBlock(_) => {
                    return Err(BackendError::UnsupportedInstruction {
                        kind: "tiled-block",
                    })
                }
            }
        }
        let local_qubits = m + g_max;
        // The whole ring (`depth` buffers of `2^local_qubits` amps) must fit the
        // card's `2^MAX_CUDA_QUBITS` amplitude budget.
        if local_qubits > MAX_CUDA_QUBITS
            || (depth as u64).saturating_mul(1u64 << local_qubits) > (1u64 << MAX_CUDA_QUBITS)
        {
            return Err(BackendError::TooManyQubits {
                requested: local_qubits,
                limit: MAX_CUDA_QUBITS,
            });
        }

        let ctx = self.ctx();

        let host_len = 2usize
            .checked_shl(n)
            .filter(|&len| len <= isize::MAX as usize / 8)
            .ok_or(BackendError::InvalidState {
                reason: "paged host state size overflow",
            })?;
        if residency {
            crate::memory::ensure_host_bytes(host_len as u64 * 8)
                .map_err(|e| to_backend_err(Error::Memory(e)))?;
            ctx.trim_pool(0).map_err(to_backend_err)?;
            let matrix_bytes = circuit
                .instructions()
                .iter()
                .filter_map(|inst| {
                    if let Instruction::Gate(gate) = inst {
                        Some(match &gate.gate {
                            aleph_core::Gate::UnitaryKq { data, .. } => data.len() as u64 * 16,
                            _ => 1024,
                        })
                    } else {
                        None
                    }
                })
                .max()
                .unwrap_or(0);
            let required = depth as u64 * ((16u64 << local_qubits) + matrix_bytes);
            let (free, _) = ctx.raw().mem_get_info().map_err(drv_err)?;
            // Reserve context/events/library overhead; this preflight is advisory
            // against concurrent users, and driver allocation errors still propagate.
            if required > (free as u64).saturating_sub(64 << 20) {
                return Err(to_backend_err(Error::Memory(
                    "resident paging ring exceeds available device memory with headroom".into(),
                )));
            }
        }
        // SAFETY: see [`Self::run_paged`] — owned page-locked alloc, every element
        // initialised before any copy reads it.
        let mut host: PinnedHostSlice<f64> = unsafe { ctx.raw().alloc_pinned(host_len) }
            .map_err(|e| to_backend_err(Error::Driver(e)))?;
        {
            let s = host
                .as_mut_slice()
                .map_err(|e| to_backend_err(Error::Driver(e)))?;
            s.fill(0.0);
            s[0] = 1.0;
        }

        // Release any pool-retained device blocks (e.g. from a prior in-core or
        // synchronous-paged run on this backend) before reserving the large ring —
        // the retaining allocator (P5-04) would otherwise stack on top and can
        // exhaust the card.
        ctx.trim_pool(0).map_err(to_backend_err)?;

        // A ring of `depth` device buffers, each big enough for the largest group.
        let mut bufs = Vec::with_capacity(depth);
        for _ in 0..depth {
            bufs.push(CudaSvState::allocate(&ctx, local_qubits).map_err(to_backend_err)?);
        }

        // Dedicated non-blocking streams for the overlapped path: gather (H2D),
        // compute, scatter (D2H). Compute must NOT run on the legacy default
        // stream — it would serialise against the copy streams and defeat the
        // overlap. The synchronous fallback (shallow gates) instead runs on the
        // legacy default stream, which gets full copy-engine bandwidth (a
        // non-blocking stream is throttled to ~half for these single-stream
        // copies). Swap the backend's context per gate accordingly.
        let h2d = ctx.raw().new_stream().map_err(drv_err)?;
        let d2h = ctx.raw().new_stream().map_err(drv_err)?;
        let compute = ctx.raw().new_stream().map_err(drv_err)?;
        let compute_ctx = ctx.with_stream(compute.clone());
        let default_ctx = ctx.clone(); // legacy default stream
        let def = ctx.stream().clone();

        let base: *mut f64 = host
            .as_mut_ptr()
            .map_err(|e| to_backend_err(Error::Driver(e)))?;

        // Stable device base pointer of each ring buffer (no realloc during the
        // run). The tile copies use **raw-FFI async** memcpy against these — going
        // through cudarc's safe `memcpy_htod`/`memcpy_dtoh` puts the context in
        // event-tracking mode and adds per-copy bookkeeping that serialises the
        // pipeline (it drops to ~0.66× of the synchronous path); raw copies keep
        // the duplex bandwidth (~1.3× over synchronous, the card's PCIe ceiling).
        let bases: Vec<sys::CUdeviceptr> = bufs
            .iter()
            .map(|b| b.amps.slice().device_ptr(&compute).0)
            .collect();
        const F64: u64 = std::mem::size_of::<f64>() as u64;

        let h = n - m;
        let saved_ctx = self.ctx();
        self.set_ctx(compute_ctx.clone());

        // Closure so `self.ctx` is restored on every exit path (including `?`).
        let result = (|| -> Result<(), BackendError> {
            // Pipeline state, persisting across gates.
            let mut slot_scatter: Vec<Option<Rc<CudaEvent>>> = vec![None; depth];
            // The most recent host write (scatter), on whatever stream — the
            // gate-boundary host-hazard barrier waits on it.
            let mut last_write: Option<Rc<CudaEvent>> = None;
            let tile_f64 = (1usize << m) * 2; // interleaved f64 per tile
            let mut ring = 0usize; // round-robin buffer index, global over the run

            // Overlap pays a duplex penalty: when both copy engines are busy each
            // direction throttles to ~8 GB/s (vs ~12.9 serial). That only nets a
            // win when the pipeline is deep enough to actually overlap gather and
            // scatter. A gate with few groups (high fan-out `hh`, so small
            // `n_outer`) can't fill the pipeline — it would engage both engines
            // without overlapping and run *slower* than serial. Such gates fall
            // back to a single-stream (synchronous) path at full per-direction
            // bandwidth. Threshold: need ≳ 2× the ring depth in groups.
            let overlap_threshold = 2 * depth as u64;

            for gates in paging_segments(circuit, m, residency) {
                let gate = gates[0];
                let plan = plan_gate(gate, m);
                let n_outer = 1u64 << (h - plan.hh);
                let n_sub = 1u64 << plan.hh;

                if n_outer >= overlap_threshold {
                    // ---- Overlapped path (deep pipeline; H2D ∥ compute ∥ D2H). ----
                    // Gate boundary: first gather must not read host tiles the
                    // previous gate may still be scattering.
                    if let Some(ev) = &last_write {
                        h2d.wait(ev).map_err(drv_err)?;
                    }
                    for outer in 0..n_outer {
                        let slot = ring % depth;
                        ring += 1;

                        // Buffer-reuse: don't overwrite a buffer still scattering.
                        if let Some(ev) = &slot_scatter[slot] {
                            h2d.wait(ev).map_err(drv_err)?;
                        }
                        // Gather the 2^hh tiles into device offsets s·2^m (H2D).
                        for s in 0..n_sub {
                            let tile = compose_high(outer, s, &plan.hprime, h);
                            let h0 = (tile as usize) << (m + 1);
                            let d0 = (s as usize) << (m + 1);
                            let dst_ptr = bases[slot] + d0 as u64 * F64;
                            // SAFETY: `base.add(h0)` in-bounds (`h0 + tile_f64 ≤
                            // 2·2^n`); host region pinned + alive; device range
                            // within the buffer; events order it vs compute/scatter.
                            let src = unsafe { std::slice::from_raw_parts(base.add(h0), tile_f64) };
                            unsafe { result::memcpy_htod_async(dst_ptr, src, h2d.cu_stream()) }
                                .map_err(drv_err)?;
                        }
                        let gather_ev = h2d.record_event(None).map_err(drv_err)?;

                        // Compute after the gather (on the compute stream).
                        compute.wait(&gather_ev).map_err(drv_err)?;
                        bufs[slot].num_qubits = m + plan.hh;
                        if plan.hh == 0 {
                            for gate in &gates {
                                self.apply_gate(&mut bufs[slot], gate)?;
                            }
                        } else {
                            self.apply_gate(&mut bufs[slot], &plan.rg)?;
                        }
                        let compute_ev = compute.record_event(None).map_err(drv_err)?;

                        // Scatter back on the D2H stream after the compute.
                        d2h.wait(&compute_ev).map_err(drv_err)?;
                        for s in 0..n_sub {
                            let tile = compose_high(outer, s, &plan.hprime, h);
                            let h0 = (tile as usize) << (m + 1);
                            let d0 = (s as usize) << (m + 1);
                            let src_ptr = bases[slot] + d0 as u64 * F64;
                            // SAFETY: same bounds as the gather; one scatter/tile.
                            let dst =
                                unsafe { std::slice::from_raw_parts_mut(base.add(h0), tile_f64) };
                            unsafe { result::memcpy_dtoh_async(dst, src_ptr, d2h.cu_stream()) }
                                .map_err(drv_err)?;
                        }
                        let sev = Rc::new(d2h.record_event(None).map_err(drv_err)?);
                        slot_scatter[slot] = Some(sev.clone());
                        last_write = Some(sev);
                    }
                } else {
                    // ---- Shallow gate: too few groups to fill the pipeline, so
                    // run it through the proven synchronous per-gate path on the
                    // legacy default stream (full per-direction bandwidth — a
                    // non-blocking stream is throttled for these single-stream
                    // copies). Swap the kernel context to the default stream. ----
                    self.set_ctx(default_ctx.clone());
                    // Gate-start barrier: prior scatters (any stream) must finish
                    // before the default stream reads/overwrites the host tiles.
                    if let Some(ev) = &last_write {
                        def.wait(ev).map_err(drv_err)?;
                    }
                    // Reuses ring buffer 0 for all groups (serial on the default
                    // stream, so no cross-group hazard).
                    if plan.hh == 0 {
                        self.apply_low_run_paged(&default_ctx, &mut bufs[0], base, n, m, &gates)?;
                    } else {
                        self.apply_gate_paged(&default_ctx, &mut bufs[0], base, n, m, gate)?;
                    }
                    let sev = Rc::new(def.record_event(None).map_err(drv_err)?);
                    // Buffer 0 was last written here; the next overlapped gather
                    // into slot 0 must wait this. (Other slots are untouched.)
                    slot_scatter[0] = Some(sev.clone());
                    last_write = Some(sev);
                    self.set_ctx(compute_ctx.clone());
                }
            }

            Ok(())
        })();

        // Drain even on an enqueue/apply error, before pinned host/ring storage
        // can drop. Try every stream rather than returning after the first error.
        let drains = [
            h2d.synchronize(),
            compute.synchronize(),
            d2h.synchronize(),
            def.synchronize(),
        ];
        self.set_ctx(saved_ctx);
        result?;
        for drain in drains {
            drain.map_err(drv_err)?;
        }
        Ok(PagedSvState {
            num_qubits: n,
            host,
        })
    }

    /// Run `circuit` out-of-core like [`Self::run_paged`], but **amortise PCIe
    /// over multi-gate tile residency** (P5.11-03). Per-gate paging streams the
    /// whole `2^n` state once *per gate*; here a maximal run of consecutive gates
    /// that touch only **low** (within-tile, `< m`) qubits is applied to each tile
    /// *while it is resident* — load the tile once, apply the entire run on-device,
    /// scatter once. That collapses a run of `L` low-qubit gates from `L` full-state
    /// PCIe passes into **one**, the single largest paging lever for locality-rich
    /// circuits (1q layers, nearest-neighbour 2q on low qubits).
    ///
    /// A low-only gate mixes amplitudes that differ only in low bits, so it never
    /// crosses a tile boundary: each tile `T` is the exact `2^m`-amplitude
    /// sub-state with the high bits fixed to `T`, and applying the run as an
    /// `m`-qubit circuit on that tile is bit-for-bit identical to applying each
    /// gate over the whole state (the oracle test pins this at 1e-10). Gates that
    /// touch any high qubit fall back to the per-gate [`Self::apply_gate_paged`]
    /// path (they need co-resident tile groups), and they flush the current run.
    ///
    /// Same arguments, restrictions, and returned state as [`Self::run_paged`].
    /// [`paged_pass_counts`] reports the per-gate vs batched full-state pass counts
    /// for a given circuit + tile split. Composes with IR fusion (the run's gates
    /// can be fused `UnitaryKq` blocks on low qubits) and is orthogonal to the
    /// copy-overlap of [`Self::run_paged_overlapped`].
    pub fn run_paged_batched(
        &mut self,
        circuit: &Circuit,
        tile_qubits: u32,
    ) -> Result<PagedSvState, BackendError> {
        let n = circuit.num_qubits();
        if n == 0 && circuit.is_empty() {
            return Err(BackendError::EmptyCircuit);
        }
        let m = tile_qubits;
        if m == 0 || m >= n {
            return Err(BackendError::InvalidState {
                reason: "paged tile_qubits must satisfy 1 <= tile_qubits < num_qubits",
            });
        }

        let mut g_max = 0u32;
        for inst in circuit.instructions() {
            match inst {
                Instruction::Gate(gate) => g_max = g_max.max(high_count(gate, m)),
                Instruction::Barrier(_) => {}
                Instruction::Measure { .. } => {
                    return Err(BackendError::UnsupportedInstruction { kind: "measure" })
                }
                Instruction::Reset(_) => {
                    return Err(BackendError::UnsupportedInstruction { kind: "reset" })
                }
                Instruction::DiagonalPhase(_) => {
                    return Err(BackendError::UnsupportedInstruction {
                        kind: "diagonal-phase",
                    })
                }
                Instruction::TiledBlock(_) => {
                    return Err(BackendError::UnsupportedInstruction {
                        kind: "tiled-block",
                    })
                }
            }
        }
        let local_qubits = m + g_max;
        if local_qubits > MAX_CUDA_QUBITS {
            return Err(BackendError::TooManyQubits {
                requested: local_qubits,
                limit: MAX_CUDA_QUBITS,
            });
        }

        let ctx = self.ctx();

        let host_len = 2usize << n; // 2 · 2^n
                                    // SAFETY: see [`Self::run_paged`] — owned page-locked alloc, every
                                    // element initialised below before any copy reads it.
        let mut host: PinnedHostSlice<f64> = unsafe { ctx.raw().alloc_pinned(host_len) }
            .map_err(|e| to_backend_err(Error::Driver(e)))?;
        {
            let s = host
                .as_mut_slice()
                .map_err(|e| to_backend_err(Error::Driver(e)))?;
            s.fill(0.0);
            s[0] = 1.0;
        }

        let mut group = CudaSvState::allocate(&ctx, local_qubits).map_err(to_backend_err)?;
        let base: *mut f64 = host
            .as_mut_ptr()
            .map_err(|e| to_backend_err(Error::Driver(e)))?;

        // Accumulate maximal runs of low-only gates; flush on any high-qubit gate.
        let mut run: Vec<&GateInstance> = Vec::new();
        for inst in circuit.instructions() {
            match inst {
                Instruction::Gate(gate) => {
                    if high_count(gate, m) == 0 {
                        run.push(gate);
                    } else {
                        if !run.is_empty() {
                            self.apply_low_run_paged(&ctx, &mut group, base, n, m, &run)?;
                            run.clear();
                        }
                        self.apply_gate_paged(&ctx, &mut group, base, n, m, gate)?;
                    }
                }
                // Barriers carry no state, so they don't break a residency run.
                Instruction::Barrier(_) => {}
                // Unreachable: the scan above rejected every other instruction.
                _ => {}
            }
        }
        if !run.is_empty() {
            self.apply_low_run_paged(&ctx, &mut group, base, n, m, &run)?;
        }

        ctx.synchronize().map_err(to_backend_err)?;
        Ok(PagedSvState {
            num_qubits: n,
            host,
        })
    }

    /// Apply a run of **low-only** gates (every qubit/control `< m`) to the whole
    /// state in one PCIe pass: each of the `2^(n-m)` tiles is gathered once, the
    /// entire run applied on its `2^m`-amplitude device sub-state (qubits map to
    /// themselves — no high bits), then scattered once. The P5.11-03 lever.
    fn apply_low_run_paged(
        &mut self,
        ctx: &CudaContext,
        group: &mut CudaSvState,
        base: *mut f64,
        n: u32,
        m: u32,
        gates: &[&GateInstance],
    ) -> Result<(), BackendError> {
        let h = n - m;
        // Each tile is a self-contained m-qubit sub-state (hh=0).
        group.num_qubits = m;
        let tile_f64 = (1usize << m) * 2; // interleaved f64 per tile
        let n_tiles = 1u64 << h;

        for tile in 0..n_tiles {
            let h0 = (tile as usize) << (m + 1); // f64 offset = tile·2^m·2
                                                 // Gather the resident tile to device offset 0.
                                                 // SAFETY: `base` valid for 2·2^n f64; `h0 + tile_f64 ≤ 2·2^n`
                                                 // since `tile < 2^h`. Stream-ordered; the tile is disjoint per iter.
            let src = unsafe { std::slice::from_raw_parts(base.add(h0), tile_f64) };
            let mut dst = group.amps.slice_mut().slice_mut(0..tile_f64);
            ctx.stream()
                .memcpy_htod(src, &mut dst)
                .map_err(|e| to_backend_err(Error::Driver(e)))?;

            // Apply the whole run while the tile is resident (low qubits ↦ self).
            for gate in gates {
                self.apply_gate(group, gate)?;
            }

            // Scatter the tile back to its host slot.
            let view = group.amps.slice().slice(0..tile_f64);
            // SAFETY: same bounds as the gather; one scatter writes this tile.
            let dst = unsafe { std::slice::from_raw_parts_mut(base.add(h0), tile_f64) };
            ctx.stream()
                .memcpy_dtoh(&view, dst)
                .map_err(|e| to_backend_err(Error::Driver(e)))?;
        }
        Ok(())
    }

    /// Apply one gate over all tile groups (see the module docs). Reuses the
    /// in-core kernels via [`Backend::apply_gate`] on the gathered device buffer.
    fn apply_gate_paged(
        &mut self,
        ctx: &CudaContext,
        group: &mut CudaSvState,
        base: *mut f64,
        n: u32,
        m: u32,
        gate: &GateInstance,
    ) -> Result<(), BackendError> {
        let h = n - m;
        // The gate's high qubits (operands ∪ controls, ascending, deduped).
        let mut high: Vec<u32> = gate
            .qubits
            .iter()
            .chain(gate.controls.iter())
            .copied()
            .filter(|&q| q >= m)
            .collect();
        high.sort_unstable();
        high.dedup();
        let hh = high.len() as u32;

        // Remap: low qubit ↦ itself; high qubit ↦ m + its rank in `high`.
        let remap = |q: u32| -> u32 {
            if q < m {
                q
            } else {
                m + high
                    .iter()
                    .position(|&x| x == q)
                    .expect("high qubit listed") as u32
            }
        };
        let mut rg = gate.clone();
        for q in rg.qubits.iter_mut() {
            *q = remap(*q);
        }
        for q in rg.controls.iter_mut() {
            *q = remap(*q);
        }

        // Use only the 2^(m+hh) prefix of the reusable group buffer.
        group.num_qubits = m + hh;

        let hprime: Vec<u32> = high.iter().map(|&q| q - m).collect();
        let tile_amps = 1usize << m; // amplitudes per tile
        let tile_f64 = tile_amps * 2; // interleaved f64 per tile
        let n_outer = 1u64 << (h - hh);
        let n_sub = 1u64 << hh;

        for outer in 0..n_outer {
            // Gather the 2^hh tiles of this group into device offsets s·2^m.
            for s in 0..n_sub {
                let tile = compose_high(outer, s, &hprime, h);
                let h0 = (tile as usize) << (m + 1); // f64 offset = tile·2^m·2
                let d0 = (s as usize) << (m + 1);
                // SAFETY: `base` is valid for `2·2^n` f64; `h0 + tile_f64 ≤ 2·2^n`
                // since `tile < 2^h`. The device view is the matching prefix slot.
                let src = unsafe { std::slice::from_raw_parts(base.add(h0), tile_f64) };
                let mut dst = group.amps.slice_mut().slice_mut(d0..d0 + tile_f64);
                ctx.stream()
                    .memcpy_htod(src, &mut dst)
                    .map_err(|e| to_backend_err(Error::Driver(e)))?;
            }

            // Apply the remapped gate on the (m+hh)-qubit device sub-state.
            self.apply_gate(group, &rg)?;

            // Scatter the tiles back to their host slots.
            for s in 0..n_sub {
                let tile = compose_high(outer, s, &hprime, h);
                let h0 = (tile as usize) << (m + 1);
                let d0 = (s as usize) << (m + 1);
                let view = group.amps.slice().slice(d0..d0 + tile_f64);
                // SAFETY: same bounds as the gather; disjoint from any concurrent
                // copy (each tile is written by exactly one scatter).
                let dst = unsafe { std::slice::from_raw_parts_mut(base.add(h0), tile_f64) };
                ctx.stream()
                    .memcpy_dtoh(&view, dst)
                    .map_err(|e| to_backend_err(Error::Driver(e)))?;
            }
        }
        Ok(())
    }
}

/// Map a raw `cudarc` driver error (from stream / event / memcpy calls) to a
/// backend error — the [`to_backend_err`] convenience for the `DriverError`-typed
/// APIs the overlapped paged path drives directly.
fn drv_err(e: cudarc::driver::DriverError) -> BackendError {
    to_backend_err(Error::Driver(e))
}

/// The device-local form of a gate for the paged executor: its qubits/controls
/// remapped (low ↦ itself, high ↦ `m + rank`), the high-qubit positions relative
/// to `m` (`hprime`), and the high-qubit count `hh`.
struct GatePlan {
    rg: GateInstance,
    hprime: Vec<u32>,
    hh: u32,
}

/// Build the [`GatePlan`] for `gate` under the low-bit split `m` (the prep shared
/// by the sync and overlapped paged paths: high-qubit set, qubit remap).
fn plan_gate(gate: &GateInstance, m: u32) -> GatePlan {
    let mut high: Vec<u32> = gate
        .qubits
        .iter()
        .chain(gate.controls.iter())
        .copied()
        .filter(|&q| q >= m)
        .collect();
    high.sort_unstable();
    high.dedup();
    let hh = high.len() as u32;

    let remap = |q: u32| -> u32 {
        if q < m {
            q
        } else {
            m + high
                .iter()
                .position(|&x| x == q)
                .expect("high qubit listed") as u32
        }
    };
    let mut rg = gate.clone();
    for q in rg.qubits.iter_mut() {
        *q = remap(*q);
    }
    for q in rg.controls.iter_mut() {
        *q = remap(*q);
    }

    let hprime: Vec<u32> = high.iter().map(|&q| q - m).collect();
    GatePlan { rg, hprime, hh }
}

// A segment is either one high gate or a maximal low-only run. Barrier
// instructions carry no state and do not interrupt residency. Non-resident
// execution keeps exactly one gate per segment for the original overlap path.
fn paging_segments(circuit: &Circuit, m: u32, residency: bool) -> Vec<Vec<&GateInstance>> {
    let mut segments: Vec<Vec<&GateInstance>> = Vec::new();
    let mut low = false;
    for inst in circuit.instructions() {
        if let Instruction::Gate(gate) = inst {
            let next_low = high_count(gate, m) == 0;
            if residency && low && next_low {
                if let Some(run) = segments.last_mut() {
                    run.push(gate);
                }
            } else {
                segments.push(vec![gate]);
            }
            low = next_low;
        }
    }
    segments
}

/// Full-state PCIe passes (one read + one write of the whole `2^n` state) that
/// [`CudaSvBackend::run_paged`] (per-gate) vs [`CudaSvBackend::run_paged_batched`]
/// (multi-gate residency) make for `circuit` under the low-bit split `m` —
/// `(per_gate, batched)`. Per-gate streams the state once per gate; batched
/// collapses each maximal run of low-only gates into one pass. The P5.11-03
/// acceptance metric (≥2× fewer passes on a locality-rich circuit) is
/// `per_gate / batched`. Barriers carry no state, so they neither cost a pass nor
/// break a run (matching the executors).
pub fn paged_pass_counts(circuit: &Circuit, tile_qubits: u32) -> (u64, u64) {
    let m = tile_qubits;
    let mut per_gate = 0u64;
    let mut batched = 0u64;
    let mut in_low_run = false;
    for inst in circuit.instructions() {
        if let Instruction::Gate(gate) = inst {
            per_gate += 1;
            if high_count(gate, m) == 0 {
                // Extend the current low run, or open a new one.
                if !in_low_run {
                    batched += 1;
                    in_low_run = true;
                }
            } else {
                // A high-qubit gate is its own pass and ends any low run.
                batched += 1;
                in_low_run = false;
            }
        }
    }
    (per_gate, batched)
}

/// Number of distinct **high** qubits (≥ `m`) a gate touches (operands ∪
/// controls) — the `hh` that sizes its co-resident tile group.
pub(crate) fn high_count(gate: &GateInstance, m: u32) -> u32 {
    let mut high: Vec<u32> = gate
        .qubits
        .iter()
        .chain(gate.controls.iter())
        .copied()
        .filter(|&q| q >= m)
        .collect();
    high.sort_unstable();
    high.dedup();
    high.len() as u32
}

#[cfg(test)]
mod tests {
    use super::{compose_high, paged_pass_counts, paging_segments};
    use aleph_ir::Circuit;

    /// `paged_pass_counts` folds each maximal run of low-only (`< m`) gates into a
    /// single batched pass while per-gate counts every gate; high-qubit gates end
    /// a run and cost a pass either way. A GPU-free check of the P5.11-03 schedule.
    #[test]
    fn pass_counts_fold_low_runs() {
        // m=2: qubits 0,1 are low. Build a low run, a high gate, then a low run.
        let mut c = Circuit::new(4, 0);
        c.h(0).unwrap(); // low
        c.h(1).unwrap(); // low  (run #1)
        c.cnot(0, 1).unwrap(); // both low → still run #1
        c.cnot(1, 2).unwrap(); // touches high q2 → flush + its own pass
        c.h(0).unwrap(); // low  (run #2)
        c.rx(0.3, 1).unwrap(); // low  → still run #2
        let (per_gate, batched) = paged_pass_counts(&c, 2);
        // 6 gates per-gate; batched = run#1 + high CNOT + run#2 = 3.
        assert_eq!(per_gate, 6);
        assert_eq!(batched, 3);
    }

    /// A purely low-only circuit folds into exactly one batched pass; a circuit
    /// where every gate touches a high qubit cannot fold (batched == per-gate).
    #[test]
    fn pass_counts_extremes() {
        let mut low = Circuit::new(4, 0);
        for _ in 0..5 {
            low.h(0).unwrap();
        }
        assert_eq!(paged_pass_counts(&low, 2), (5, 1));

        let mut high = Circuit::new(4, 0); // m=1 ⇒ q1,q2,q3 high
        high.cnot(1, 2).unwrap();
        high.cnot(2, 3).unwrap();
        assert_eq!(paged_pass_counts(&high, 1), (2, 2));
    }

    #[test]
    fn resident_segments_preserve_gate_order_and_flush_high_controls() {
        use aleph_core::{Gate, GateInstance};
        let mut c = Circuit::new(5, 0);
        c.h(0).unwrap();
        c.barrier([0, 1]).unwrap();
        c.h(1).unwrap();
        c.add_gate(GateInstance::controlled(Gate::X, vec![0], vec![4]))
            .unwrap();
        c.h(0).unwrap();
        let segments = paging_segments(&c, 2, true);
        assert_eq!(segments.iter().map(Vec::len).collect::<Vec<_>>(), [2, 1, 1]);
        let flat: Vec<_> = segments.into_iter().flatten().collect();
        let original: Vec<_> = paging_segments(&c, 2, false)
            .into_iter()
            .flatten()
            .collect();
        assert_eq!(flat.len(), original.len());
        assert!(flat.iter().zip(original).all(|(a, b)| std::ptr::eq(*a, b)));
        assert_eq!(flat.len() as u64, paged_pass_counts(&c, 2).0);
    }

    /// `compose_high` must place `s` into the `hprime` bit positions and `outer`
    /// into the rest, LSB-first, so the `2^hh` sub-tiles of a group differ only in
    /// the high qubits the gate touches.
    #[test]
    fn compose_high_scatters_bits() {
        // h=4 high bits, gate touches high positions {1, 3} (hprime).
        let hprime = [1u32, 3u32];
        let h = 4;
        // outer fills positions {0, 2}. outer=0b11 → bit0=1, bit2=1.
        // s fills positions {1, 3}. s=0b10 → rank0(pos1)=0, rank1(pos3)=1 ⇒ bit3=1.
        // expected = bits {0,2,3} set = 0b1101 = 13.
        assert_eq!(compose_high(0b11, 0b10, &hprime, h), 0b1101);
        // s=0 outer=0 ⇒ 0; s=0b11 ⇒ bits 1,3 ⇒ 0b1010=10; outer=0b01 ⇒ bit0 ⇒ +1.
        assert_eq!(compose_high(0, 0, &hprime, h), 0);
        assert_eq!(compose_high(0, 0b11, &hprime, h), 0b1010);
        assert_eq!(compose_high(0b01, 0b11, &hprime, h), 0b1011);
    }
}
